package dev.crez.il2cppdumper

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

class LongList {
    var a = LongArray(1 shl 16)
    var n = 0
    fun add(v: Long) { if (n == a.size) a = a.copyOf(n * 2); a[n++] = v }
}

fun mmap(f: File): ByteBuffer = RandomAccessFile(f, "r").use { r ->
    r.channel.map(FileChannel.MapMode.READ_ONLY, 0, r.length()).order(ByteOrder.LITTLE_ENDIAN)
}

/** ELF64 aarch64: PT_LOAD map + R_AARCH64_RELATIVE overlay (RELA / Android APS2). RELR works in-place. */
class Elf(val b: ByteBuffer) {
    class Seg(val va: Long, val off: Long, val fsz: Long, val flags: Int)

    val segs = ArrayList<Seg>()
    var ro = LongArray(0)   // reloc target vaddr, sorted
    var ra = LongArray(0)   // addend

    init {
        require(b.getInt(0) == 0x464c457f) { "не ELF" }
        require(b.get(4).toInt() == 2 && (b.getShort(0x12).toInt() and 0xffff) == 183) { "нужен arm64 libil2cpp.so" }
        val phoff = b.getLong(0x20).toInt()
        val phes = b.getShort(0x36).toInt() and 0xffff
        val phn = b.getShort(0x38).toInt() and 0xffff
        var dOff = -1
        var dSz = 0
        for (i in 0 until phn) {
            val p = phoff + i * phes
            val type = b.getInt(p)
            val fl = b.getInt(p + 4)
            val off = b.getLong(p + 8)
            val va = b.getLong(p + 16)
            val fsz = b.getLong(p + 32)
            if (type == 1) segs.add(Seg(va, off, fsz, fl))
            if (type == 2) { dOff = off.toInt(); dSz = fsz.toInt() }
        }
        loadRelocs(dOff, dSz)
    }

    private fun loadRelocs(dOff: Int, dSz: Int) {
        if (dOff < 0) return
        var rela = 0L; var relaSz = 0L; var arela = 0L
        var p = dOff
        while (p + 16 <= dOff + dSz) {
            val tag = b.getLong(p)
            val v = b.getLong(p + 8)
            if (tag == 0L) break
            when (tag) {
                7L -> rela = v
                8L -> relaSz = v
                0x6000000fL -> arela = v
            }
            p += 16
        }
        val o = LongList()
        val a = LongList()
        if (rela != 0L && relaSz > 0) {
            val s = v2o(rela).toInt()
            var q = s
            while (q < s + relaSz) {
                if ((b.getLong(q + 8) and 0xffffffffL) == 1027L) { o.add(b.getLong(q)); a.add(b.getLong(q + 16)) }
                q += 24
            }
        }
        if (arela != 0L && v2o(arela) >= 0) {
            var q = v2o(arela).toInt()
            if (b.getInt(q) == 0x32535041) { // "APS2"
                q += 4
                fun sleb(): Long {
                    var r = 0L; var sh = 0; var by: Int
                    do {
                        by = b.get(q++).toInt() and 0xff
                        r = r or ((by and 0x7f).toLong() shl sh)
                        sh += 7
                    } while ((by and 0x80) != 0)
                    if (sh < 64 && (by and 0x40) != 0) r = r or (-1L shl sh)
                    return r
                }
                val total = sleb()
                var rOff = sleb()
                var rInfo = 0L
                var rAdd = 0L
                var done = 0L
                while (done < total) {
                    val gs = sleb()
                    val gf = sleb().toInt()
                    val byInfo = (gf and 1) != 0
                    val byDelta = (gf and 2) != 0
                    val byAdd = (gf and 4) != 0
                    val hasAdd = (gf and 8) != 0
                    var gDelta = 0L
                    if (byDelta) gDelta = sleb()
                    if (byInfo) rInfo = sleb()
                    if (hasAdd && byAdd) rAdd += sleb()
                    if (!hasAdd) rAdd = 0
                    for (i in 0L until gs) {
                        rOff += if (byDelta) gDelta else sleb()
                        if (!byInfo) rInfo = sleb()
                        if (hasAdd && !byAdd) rAdd += sleb()
                        if ((rInfo and 0xffffffffL) == 1027L) { o.add(rOff); a.add(rAdd) }
                    }
                    done += gs
                }
            }
        }
        var sorted = true
        for (i in 1 until o.n) if (o.a[i] < o.a[i - 1]) { sorted = false; break }
        if (sorted) {
            ro = o.a.copyOf(o.n); ra = a.a.copyOf(a.n)
        } else {
            val idx = (0 until o.n).sortedBy { o.a[it] }
            ro = LongArray(o.n) { o.a[idx[it]] }
            ra = LongArray(o.n) { a.a[idx[it]] }
        }
    }

    fun v2o(va: Long): Long {
        for (s in segs) if (va >= s.va && va < s.va + s.fsz) return s.off + (va - s.va)
        return -1
    }

    fun o2v(off: Long): Long {
        for (s in segs) if (off >= s.off && off < s.off + s.fsz) return s.va + (off - s.off)
        return -1
    }

    fun valid(va: Long) = va != 0L && v2o(va) >= 0

    fun isExec(va: Long): Boolean {
        for (s in segs) if (va >= s.va && va < s.va + s.fsz) return (s.flags and 1) != 0
        return false
    }

    fun ptr(va: Long): Long {
        val i = java.util.Arrays.binarySearch(ro, va)
        if (i >= 0) return ra[i]
        val o = v2o(va)
        return if (o < 0 || o + 8 > b.limit()) 0 else b.getLong(o.toInt())
    }

    fun int(va: Long): Int {
        val o = v2o(va)
        return if (o < 0 || o + 4 > b.limit()) 0 else b.getInt(o.toInt())
    }

    fun u8(va: Long): Int {
        val o = v2o(va)
        return if (o < 0) 0 else b.get(o.toInt()).toInt() and 0xff
    }
}
