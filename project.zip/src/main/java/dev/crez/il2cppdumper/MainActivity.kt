package dev.crez.il2cppdumper

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private var metaUri: Uri? = null
    private var libUri: Uri? = null
    private lateinit var logView: TextView
    private lateinit var bMeta: Button
    private lateinit var bLib: Button
    private lateinit var etPkg: EditText

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 96, 32, 32) }
        etPkg = EditText(this).apply { setText("com.catsbit.oxidesurvivalisland"); textSize = 13f; setSingleLine() }
        val bMem = Button(this).apply { text = "0. МЕТАДАТА ИЗ ПАМЯТИ (root, игра запущена)"; setOnClickListener { mem() } }
        bMeta = Button(this).apply { text = "1. global-metadata.dat"; setOnClickListener { pick(1) } }
        bLib = Button(this).apply { text = "2. libil2cpp.so"; setOnClickListener { pick(2) } }
        val bGo = Button(this).apply { text = "3. DUMP"; setOnClickListener { go() } }
        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        val sv = ScrollView(this).apply { addView(logView) }
        root.addView(etPkg); root.addView(bMem)
        root.addView(bMeta); root.addView(bLib); root.addView(bGo)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun mem() {
        val pkg = etPkg.text.toString().trim()
        if (!Regex("[A-Za-z0-9._]+").matches(pkg)) { log("плохое имя пакета"); return }
        log("жди, скан памяти может занять минуту-две...")
        Thread {
            try {
                log(MemDump(pkg) { log(it) }.run())
            } catch (t: Throwable) {
                log("ОШИБКА: " + t.javaClass.simpleName + ": " + t.message)
            }
        }.start()
    }

    private fun pick(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        startActivityForResult(i, code)
    }

    private fun go() {
        if (metaUri == null || libUri == null) { log("выбери оба файла"); return }
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*").putExtra(Intent.EXTRA_TITLE, "dump.cs")
        startActivityForResult(i, 3)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data ?: return
        if (res != RESULT_OK) return
        when (req) {
            1 -> { metaUri = u; bMeta.text = "1. metadata: ok" }
            2 -> { libUri = u; bLib.text = "2. lib: ok" }
            3 -> run(u)
        }
    }

    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }

    private fun copy(u: Uri, name: String): File {
        val f = File(cacheDir, name)
        contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
        return f
    }

    private fun run(out: Uri) {
        Thread {
            try {
                log("копирую файлы...")
                val mf = copy(metaUri!!, "meta.dat")
                val lf = copy(libUri!!, "lib.so")
                contentResolver.openOutputStream(out)!!.bufferedWriter().use { w ->
                    Dumper(mf, lf) { log(it) }.run(w)
                }
                log("готово")
            } catch (t: Throwable) {
                log("ОШИБКА: " + t.javaClass.simpleName + ": " + t.message)
            }
        }.start()
    }
}
