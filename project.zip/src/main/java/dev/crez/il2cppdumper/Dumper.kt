package dev.crez.il2cppdumper

import java.io.File
import java.io.Writer
import java.nio.ByteBuffer

/**
 * metadata v27..31, arm64. Header pair idx: 2 str, 5 methods, 10 params, 11 fields, 12 genParams,
 * 14 genContainers, 16 interfaces, 19 typeDefs, 20 images.
 */
class Dumper(private val mf: File, private val lf: File, private val log: (String) -> Unit) {
    private lateinit var m: ByteBuffer
    private lateinit var elf: Elf
    private var ver = 0
    private var nTd = 0
    private var mr = 0L
    private var typeVa = LongArray(0)
    private lateinit var tcache: Array<String?>
    private lateinit var tdImg: IntArray
    private class Mod(val mp: Long, val cnt: Int)
    private val mods = HashMap<Int, Mod>()
    private class T(val data: Long, val bits: Int) {
        val type: Int get() = (bits shr 16) and 0xff
        val attrs: Int get() = bits and 0xffff
        val byref: Boolean get() = ((bits shr 29) and 1) != 0
    }

    private fun tab(p: Int) = m.getInt(8 + 8 * p)
    private fun tsz(p: Int) = m.getInt(12 + 8 * p)

    private fun str(i: Int): String {
        val s = tab(2) + i
        var e = s
        while (m.get(e).toInt() != 0) e++
        val ba = ByteArray(e - s)
        m.position(s); m.get(ba)
        return String(ba, Charsets.UTF_8)
    }

    // typedef (88 bytes)
    private fun tdI(i: Int, f: Int) = m.getInt(tab(19) + i * 88 + f)
    private fun tdS(i: Int, f: Int) = m.getShort(tab(19) + i * 88 + f).toInt() and 0xffff
    private fun imI(i: Int, f: Int) = m.getInt(tab(20) + i * 40 + f)

    private fun gpNames(gc: Int): List<String> {
        val b = tab(14) + gc * 16
        val argc = m.getInt(b + 4)
        val start = m.getInt(b + 12)
        return (0 until argc).map { str(m.getInt(tab(12) + (start + it) * 16 + 4)) }
    }

    private fun gpName(i: Int): String = try { str(m.getInt(tab(12) + i * 16 + 4)) } catch (e: Exception) { "T$i" }

    private fun typeAt(i: Int): T {
        val va = typeVa[i]
        return T(elf.ptr(va), elf.int(va + 8))
    }

    private fun readType(va: Long) = T(elf.ptr(va), elf.int(va + 8))

    private fun typeStr(i: Int): String {
        tcache[i]?.let { return it }
        val s = tname(typeAt(i), 0)
        tcache[i] = s
        return s
    }

    private fun simpleName(ti: Int): String {
        var n = str(tdI(ti, 0))
        val k = n.indexOf('`'); if (k >= 0) n = n.substring(0, k)
        val gc = tdI(ti, 24)
        return if (gc >= 0) n + "<" + gpNames(gc).joinToString(", ") + ">" else n
    }

    private fun tdName(ti: Int, args: List<String>?, depth: Int): String {
        if (ti < 0 || ti >= nTd) return "T?"
        var n = str(tdI(ti, 0))
        val k = n.indexOf('`'); if (k >= 0) n = n.substring(0, k)
        val gc = tdI(ti, 24)
        if (gc >= 0) n += "<" + (args ?: gpNames(gc)).joinToString(", ") + ">"
        val decl = tdI(ti, 12)
        val ns = str(tdI(ti, 4))
        return when {
            decl >= 0 -> tname(typeAt(decl), depth + 1) + "." + n
            ns.isEmpty() -> n
            else -> "$ns.$n"
        }
    }

    private fun tname(t: T, depth: Int): String {
        if (depth > 8) return "?"
        val s = when (t.type) {
            1 -> "void"; 2 -> "bool"; 3 -> "char"; 4 -> "sbyte"; 5 -> "byte"; 6 -> "short"; 7 -> "ushort"
            8 -> "int"; 9 -> "uint"; 10 -> "long"; 11 -> "ulong"; 12 -> "float"; 13 -> "double"; 14 -> "string"
            0x16 -> "TypedReference"; 0x18 -> "IntPtr"; 0x19 -> "UIntPtr"; 0x1c -> "object"
            0x11, 0x12 -> tdName(t.data.toInt(), null, depth)
            0x13, 0x1e -> gpName(t.data.toInt())
            0xf -> tname(readType(t.data), depth + 1) + "*"
            0x1d -> tname(readType(t.data), depth + 1) + "[]"
            0x14 -> {
                val et = readType(elf.ptr(t.data))
                val rank = elf.u8(t.data + 8)
                tname(et, depth + 1) + "[" + ",".repeat(maxOf(rank - 1, 0)) + "]"
            }
            0x15 -> {
                val g = t.data
                val ti = elf.ptr(g).toInt()
                val inst = elf.ptr(g + 8)
                val argc = elf.int(inst)
                val argv = elf.ptr(inst + 8)
                val args = (0 until argc).map { tname(readType(elf.ptr(argv + 8L * it)), depth + 1) }
                tdName(ti, args, depth)
            }
            else -> "type_${t.type}"
        }
        return s
    }

    private fun access(a: Int) = when (a and 7) {
        1 -> "private "; 2 -> "private protected "; 3 -> "internal "; 4 -> "protected "
        5 -> "protected internal "; 6 -> "public "; else -> ""
    }

    private fun locateModules(names: List<String>) {
        val want = HashMap<String, Int>()
        names.forEachIndexed { i, n -> want[n] = i }
        val nameVa = HashMap<Long, Int>()
        var lo = Long.MAX_VALUE
        var hi = 0L
        val lb = elf.b
        for (s in elf.segs) {
            var o = s.off.toInt()
            val end = (s.off + s.fsz).toInt() - 5
            while (o < end) {
                if (lb.get(o) == 0x2e.toByte() && lb.get(o + 1) == 0x64.toByte() && lb.get(o + 2) == 0x6c.toByte() &&
                    lb.get(o + 3) == 0x6c.toByte() && lb.get(o + 4) == 0.toByte()) {
                    var st = o
                    while (st > s.off && o - st < 256 && lb.get(st - 1) != 0.toByte()) st--
                    val ba = ByteArray(o + 4 - st)
                    lb.position(st); lb.get(ba)
                    val idx = want[String(ba, Charsets.UTF_8)]
                    if (idx != null) {
                        val va = s.va + (st - s.off)
                        nameVa[va] = idx
                        if (va < lo) lo = va
                        if (va > hi) hi = va
                    }
                }
                o++
            }
        }
        fun consider(slot: Long, img: Int) {
            if (mods.containsKey(img)) return
            val c = elf.int(slot + 8)
            val mp = elf.ptr(slot + 16)
            if (c !in 0..3_000_000 || !elf.valid(mp)) return
            for (k in 0 until minOf(c, 16)) {
                val p = elf.ptr(mp + 8L * k)
                if (p != 0L && !elf.isExec(p)) return
            }
            mods[img] = Mod(mp, c)
        }
        for (i in elf.ro.indices) {
            val img = nameVa[elf.ra[i]]
            if (img != null) consider(elf.ro[i], img)
        }
        for (s in elf.segs) {
            if ((s.flags and 1) != 0) continue
            var o = s.off.toInt()
            val end = (s.off + s.fsz).toInt() - 8
            while (o < end) {
                val q = lb.getLong(o)
                if (q in lo..hi) {
                    val img = nameVa[q]
                    if (img != null) consider(s.va + (o - s.off), img)
                }
                o += 8
            }
        }
    }

    private fun findMR(): Long {
        val lb = elf.b
        for (s in elf.segs) {
            if ((s.flags and 1) != 0) continue
            var o = s.off.toInt()
            val end = (s.off + s.fsz).toInt() - 24
            while (o < end) {
                if (lb.getInt(o) == nTd && lb.getInt(o + 16) == nTd) {
                    val a = s.va + (o - s.off)
                    val base = a - 80
                    if (elf.valid(base) && elf.valid(elf.ptr(a + 8)) && elf.valid(elf.ptr(a + 24))) {
                        val tc = elf.int(base + 48)
                        if (tc >= nTd && tc < 2_000_000 && elf.valid(elf.ptr(base + 56))) return base
                    }
                }
                o += 8
            }
        }
        return -1
    }

    fun run(w: Writer) {
        m = mmap(mf)
        require((m.getInt(0).toLong() and 0xffffffffL) == 0xFAB11BAFL) { "metadata: плохая сигнатура (зашифрована/не стоковая)" }
        ver = m.getInt(4)
        require(ver in 27..31) { "metadata v$ver не поддерживается (27-31)" }
        val ms = if (ver >= 31) 36 else 32
        require(tsz(19) % 88 == 0 && tsz(5) % ms == 0 && tsz(11) % 12 == 0 && tsz(10) % 12 == 0 &&
            tsz(20) % 40 == 0 && tsz(12) % 16 == 0 && tsz(14) % 16 == 0) { "layout таблиц не совпал с v$ver" }
        nTd = tsz(19) / 88
        val nImg = tsz(20) / 40
        log("metadata v$ver, typedefs=$nTd, images=$nImg")

        log("читаю ELF...")
        elf = Elf(mmap(lf))
        log("relocs=${elf.ro.size}")

        mr = findMR()
        require(mr > 0) { "MetadataRegistration не найден (lib не от этой metadata / не arm64 / защищена)" }
        val tc = elf.int(mr + 48)
        val tp = elf.ptr(mr + 56)
        typeVa = LongArray(tc) { elf.ptr(tp + 8L * it) }
        tcache = arrayOfNulls(tc)
        val foBase = elf.ptr(mr + 88)
        log("MetadataRegistration @0x%X, types=%d".format(mr, tc))

        val names = (0 until nImg).map { str(imI(it, 0)) }
        tdImg = IntArray(nTd) { -1 }
        for (i in 0 until nImg) {
            val ts = imI(i, 8); val tcn = imI(i, 12)
            for (t in ts until ts + tcn) if (t in 0 until nTd) tdImg[t] = i
        }
        log("ищу CodeGenModules...")
        locateModules(names)
        log("модулей найдено: ${mods.size}/$nImg")

        val d = if (ver >= 31) 4 else 0
        var done = 0
        for (im in 0 until nImg) {
            val ts = imI(im, 8)
            val tcn = imI(im, 12)
            w.write("\n// Dll : ${names[im]}\n")
            for (ti in ts until ts + tcn) {
                try {
                    dumpType(ti, im, w, ms, d, foBase)
                } catch (e: Exception) {
                    w.write("// ERROR typedef $ti: ${e.javaClass.simpleName}\n")
                }
            }
            done++
            if (done % 10 == 0) log("images $done/$nImg")
        }
        w.flush()
    }

    private fun rva(img: Int, token: Int): Long {
        val md = mods[img] ?: return -1
        val rid = (token and 0xffffff) - 1
        if (rid < 0 || rid >= md.cnt) return -1
        return elf.ptr(md.mp + 8L * rid)
    }

    private fun dumpType(ti: Int, img: Int, w: Writer, ms: Int, d: Int, foBase: Long) {
        val fl = tdI(ti, 28)
        val par = tdI(ti, 16)
        val pn = if (par >= 0) typeStr(par) else ""
        val vs = when (fl and 7) {
            0, 5 -> "internal "; 1, 2 -> "public "; 3 -> "private "; 4 -> "protected "
            6 -> "private protected "; else -> "protected internal "
        }
        val isIface = (fl and 0x20) != 0
        val kind = when {
            isIface -> "interface"
            pn == "System.Enum" -> "enum"
            pn == "System.ValueType" -> "struct"
            else -> "class"
        }
        var extra = ""
        if (kind == "class") {
            val ab = (fl and 0x80) != 0
            val se = (fl and 0x100) != 0
            extra = when { ab && se -> "static "; ab -> "abstract "; se -> "sealed "; else -> "" }
        }
        val bases = ArrayList<String>()
        if (kind == "class" && par >= 0 && pn != "System.Object") bases.add(pn)
        val is0 = tdI(ti, 52)
        val ic = tdS(ti, 76)
        for (k in 0 until ic) bases.add(typeStr(m.getInt(tab(16) + (is0 + k) * 4)))
        val ext = if (bases.isEmpty()) "" else " : " + bases.joinToString(", ")

        val sb = StringBuilder()
        sb.append("\n// Namespace: ").append(str(tdI(ti, 4))).append('\n')
        sb.append(vs).append(extra).append(kind).append(' ').append(simpleName(ti)).append(ext)
            .append(" // TypeDefIndex: ").append(ti).append("\n{\n")

        val fs = tdI(ti, 32)
        val fc = tdS(ti, 68)
        if (fc > 0) sb.append("\t// Fields\n")
        for (k in 0 until fc) {
            val fb = tab(11) + (fs + k) * 12
            val name = str(m.getInt(fb))
            val t = typeAt(m.getInt(fb + 4))
            val a = t.attrs
            val isStatic = (a and 0x10) != 0
            var mods = access(a)
            if (isStatic) mods += if ((a and 0x40) != 0) "const " else "static "
            else if ((a and 0x20) != 0) mods += "readonly "
            sb.append('\t').append(mods).append(tname(t, 0)).append(' ').append(name).append(';')
            var off = -1
            val p = if (foBase != 0L) elf.ptr(foBase + 8L * ti) else 0L
            if (p != 0L) off = elf.int(p + 4L * k)
            if (off > 0 && kind == "struct" && !isStatic) off -= 16
            if (off >= 0) sb.append(" // 0x%X".format(off))
            sb.append('\n')
        }

        val m0 = tdI(ti, 36)
        val mc = tdS(ti, 64)
        if (mc > 0) sb.append("\n\t// Methods\n")
        for (k in 0 until mc) {
            val mb = tab(5) + (m0 + k) * ms
            val name = str(m.getInt(mb))
            val ret = typeAt(m.getInt(mb + 8))
            val ps = m.getInt(mb + 12 + d)
            val gc = m.getInt(mb + 16 + d)
            val token = m.getInt(mb + 20 + d)
            val mfl = m.getShort(mb + 24 + d).toInt() and 0xffff
            val pc = m.getShort(mb + 30 + d).toInt() and 0xffff
            var mods = access(mfl)
            if ((mfl and 0x10) != 0) mods += "static "
            if ((mfl and 0x400) != 0) mods += "abstract "
            else if ((mfl and 0x40) != 0) mods += if ((mfl and 0x100) != 0) "virtual " else "override "
            val ps2 = (0 until pc).joinToString(", ") {
                val pb = tab(10) + (ps + it) * 12
                val pt = typeAt(m.getInt(pb + 8))
                (if (pt.byref) "ref " else "") + tname(pt, 0) + " " + str(m.getInt(pb))
            }
            val gn = if (gc >= 0) "<" + gpNames(gc).joinToString(", ") + ">" else ""
            val r = rva(img, token)
            if (r > 0) sb.append("\t// RVA: 0x%X Offset: 0x%X\n".format(r, elf.v2o(r)))
            else sb.append("\t// RVA: -\n")
            sb.append('\t').append(mods).append(if (ret.byref) "ref " else "").append(tname(ret, 0))
                .append(' ').append(name).append(gn).append('(').append(ps2).append(") { }\n\n")
        }
        sb.append("}\n")
        w.write(sb.toString())
    }
}
