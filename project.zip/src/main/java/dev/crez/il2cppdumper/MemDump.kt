package dev.crez.il2cppdumper

/** Root: ищет в памяти запущенной игры расшифрованный global-metadata (сигнатура AF 1B B1 FA) и сохраняет в Download. */
class MemDump(private val pkg: String, private val log: (String) -> Unit) {
    private class Hit(val addr: Long, val total: Long, val ver: Int)

    private fun su(cmd: String): Process =
        ProcessBuilder("su", "-c", cmd).redirectError(ProcessBuilder.Redirect.DISCARD).start()

    private fun suText(cmd: String): String {
        val p = su(cmd)
        val t = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return t
    }

    private fun le(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8) or
            ((b[o + 2].toInt() and 0xff) shl 16) or ((b[o + 3].toInt() and 0xff) shl 24)

    private fun check(b: ByteArray, i: Int, have: Int, addr: Long, hits: MutableList<Hit>) {
        if (i + 8 + 8 * 22 > have) return
        val ver = le(b, i + 4)
        val first = le(b, i + 8)
        log("сигнатура @0x%X ver=%d first=%d".format(addr, ver, first))
        if (first < 16 || first > 1024 || first % 8 != 0) return
        val pairs = (first - 8) / 8
        if (i + 8 + pairs * 8 > have) return
        var total = 0L
        for (k in 0 until pairs) {
            val off = le(b, i + 8 + 8 * k).toLong() and 0xffffffffL
            val sz = le(b, i + 12 + 8 * k).toLong() and 0xffffffffL
            if (off > 0) total = maxOf(total, off + sz)
        }
        if (total < (1L shl 20) || total > (400L shl 20)) return
        hits.add(Hit(addr, total, ver))
        log("  кандидат: size=%d MB".format(total shr 20))
    }

    private fun scan(pid: String, s: Long, e: Long, hits: MutableList<Hit>) {
        val p = su("dd if=/proc/$pid/mem bs=4096 skip=${s / 4096} count=${(e - s) / 4096} 2>/dev/null")
        val ins = p.inputStream
        val buf = ByteArray((1 shl 20) + 1024)
        var have = 0
        var base = s
        var eof = false
        try {
            while (!eof) {
                val n = ins.read(buf, have, buf.size - have)
                if (n < 0) eof = true else have += n
                if (!eof && have < buf.size) continue
                val limit = if (eof) have - 4 else have - 1024
                var i = 0
                while (i <= limit) {
                    if (buf[i] == 0xAF.toByte() && buf[i + 1] == 0x1B.toByte() &&
                        buf[i + 2] == 0xB1.toByte() && buf[i + 3] == 0xFA.toByte()) {
                        check(buf, i, have, base + i, hits)
                    }
                    i++
                }
                if (!eof) {
                    System.arraycopy(buf, have - 1024, buf, 0, 1024)
                    base += (have - 1024)
                    have = 1024
                }
            }
        } finally {
            p.destroy()
        }
    }

    fun run(): String {
        val pidOut = suText("pidof $pkg").trim()
        require(pidOut.isNotEmpty()) { "игра не запущена (pidof пустой) или нет root" }
        val pid = pidOut.split(Regex("\\s+"))[0]
        log("pid=$pid")
        val maps = suText("cat /proc/$pid/maps")
        val rx = Regex("^([0-9a-f]+)-([0-9a-f]+) (\\S{4}) \\S+ \\S+ \\S+\\s*(.*)$")
        val regs = ArrayList<LongArray>()
        for (line in maps.lines()) {
            val m = rx.find(line) ?: continue
            val perms = m.groupValues[3]
            val path = m.groupValues[4].trim()
            if (perms[0] != 'r' || perms[3] != 'p') continue
            if (path.isNotEmpty() && !path.startsWith("[anon") && !path.startsWith("[heap")) continue
            if (path.startsWith("[anon:dalvik")) continue
            val s = m.groupValues[1].toLong(16)
            val e = m.groupValues[2].toLong(16)
            if (e - s < (1L shl 20)) continue
            regs.add(longArrayOf(s, e))
        }
        require(regs.isNotEmpty()) { "maps пустой: нет root или процесс не тот" }
        log("регионов: ${regs.size}, ~${regs.sumOf { it[1] - it[0] } shr 20} MB")

        val hits = ArrayList<Hit>()
        for ((idx, r) in regs.withIndex()) {
            try { scan(pid, r[0], r[1], hits) } catch (e: Exception) { log("регион ${idx}: ${e.message}") }
            if (idx % 20 == 0) log("скан ${idx}/${regs.size}")
            if (hits.any { it.ver in 27..31 }) break
        }
        val best = hits.filter { it.ver in 27..31 }.maxByOrNull { it.total }
            ?: hits.maxByOrNull { it.total }
            ?: error("метадата в памяти не найдена: запусти игру до главного меню и повтори")
        if (best.ver !in 27..31) log("ВНИМАНИЕ: версия ${best.ver} нестандартная, дампер её не примет")

        val start = best.addr and 4095L.inv()
        val lead = best.addr - start
        val count = (lead + best.total + 4095) / 4096
        val out = "/sdcard/Download/global-metadata.dat"
        suText("dd if=/proc/$pid/mem bs=4096 skip=${start / 4096} count=$count 2>/dev/null | tail -c +${lead + 1} | head -c ${best.total} > $out")
        val sz = suText("stat -c %s $out").trim()
        require(sz == best.total.toString()) { "размер файла $sz, ожидался ${best.total}" }
        return "сохранено: Download/global-metadata.dat ($sz байт, v${best.ver}). теперь кнопка 1 -> этот файл"
    }
}
